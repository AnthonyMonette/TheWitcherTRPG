# FoundryVTT system - The witcher TRPG#

## Character Sheet ##
This Sheet represent a Player character with all of it's stats

### Skill Tab ###
This tabs allows you to roll skills and keep track of your improvement Points

### Race and Profession Tab ### 
This tab is used to handle the race and profession.
It allows you to roll the professions skills.
You can create Items of type Race and/or profession To drag and drop in the caracter sheet.

### Inventory Tab ### 
This tab is used to organize different sort of items that the character is carrying.
You can see the total carrying weight 
Weapons
Armor
Valuables
Substances and Components
Diagrams

### Magic Tab ### 
This tab is used to organize your Spell, invocations, witcher signs, rituals and hexes.
It also keep tracks of your current stamina and Focuses

### Background Tab ### 
This tab is used to choose your origine and create your background. 
You can keep tracks of your life events and also you can add multiple notes for your characters.  
Those could be anything, maybe notes on specific NPC that they encounters, your critical wounds, short stories in your backgrouds, etc. 

## Monster Sheet ##
### Skill Tab ###
### Attacks/Loot ###
### Details Tab ###
### Spells Tab ###

## Item Sheet ##
Race
Profession
Weapon
Armor
Valuables
Components
Diagrams
Spells
Notes